# Change Log

All notable changes to this project will be documented in this file.


## v4.0.2

Bug fix in icon path


## v4.0.1

SumTimings now working as expected
Response Time Health now dsiplayed in node statistics
External Icons now use the correct path


## v4.0.0

Ported project to react.
aggregationType is not needed as template variable anymore.
Unit type of data now can be choosen.
Tables of Incoming/Outgoing Statistics are now sortable.
Settings needed for the dummy data to be displayed is now filled in automatically when dummy data is activated.
Service Icons can now be customized for both Internal and External Services.
