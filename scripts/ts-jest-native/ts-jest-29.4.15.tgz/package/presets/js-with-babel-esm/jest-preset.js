module.exports = require('..').jsWithBabelESM
