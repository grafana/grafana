module.exports = require('..').jsWithBabelLegacy
