module.exports = require('..').jsWithTsESM
