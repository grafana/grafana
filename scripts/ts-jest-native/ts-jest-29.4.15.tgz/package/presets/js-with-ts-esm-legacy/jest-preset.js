module.exports = require('..').jsWithTsESMLegacy
