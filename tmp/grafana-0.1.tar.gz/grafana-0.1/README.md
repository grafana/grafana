# Grafana

Experimenting with a a custom graph dashboard based on [kibana](https://github.com/elasticsearch/kibana).

