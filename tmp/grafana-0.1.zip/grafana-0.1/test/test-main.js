/*! grafana - v0.1 - 2014-01-19
 * Copyright (c) 2014 Torkel Ödegaard; Licensed Apache License */

require.config({baseUrl:"base",paths:{underscore:"app/components/underscore.extended","underscore-src":"vendor/underscore"},shim:{underscore:{exports:"_"}}}),require(["test/specs/lexer-specs","test/specs/parser-specs","test/specs/gfunc-specs"],function(){window.__karma__.start()});