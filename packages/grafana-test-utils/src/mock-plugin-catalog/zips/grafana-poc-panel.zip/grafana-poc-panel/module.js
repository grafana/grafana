/* [create-plugin] version: 7.9.0 */
/* [create-plugin] plugin: grafana-poc-panel@1.0.0 */
define(["@emotion/css","@grafana/data","@grafana/runtime","@grafana/ui","module","react"],(e,t,a,r,n,o)=>(()=>{"use strict";var l={89(t){t.exports=e},781(e){e.exports=t},531(e){e.exports=a},7(e){e.exports=r},308(e){e.exports=n},959(e){e.exports=o}};const i={};function s(e){const t=i[e];if(void 0!==t)return t.exports;const a=i[e]={exports:{}};return l[e](a,a.exports,s),a.exports}s.n=e=>{const t=e&&e.__esModule?()=>e.default:()=>e;return s.d(t,{a:t}),t},s.d=(e,t)=>{if(Array.isArray(t))for(var a=0;a<t.length;){var r=t[a++],n=t[a++];s.o(e,r)?0===n&&a++:0===n?Object.defineProperty(e,r,{enumerable:!0,value:t[a++]}):Object.defineProperty(e,r,{enumerable:!0,get:n})}else for(var r in t)s.o(t,r)&&!s.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},s.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),s.r=e=>{Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},s.p="public/plugins/grafana-poc-panel/";let p={};s.r(p),s.d(p,{plugin:()=>w});var u=s(308),d=s.n(u);s.p=d()&&d().uri?d().uri.slice(0,d().uri.lastIndexOf("/")+1):"public/plugins/grafana-poc-panel/";var c=s(781),m=s(959),f=s.n(m),g=s(89),x=s(7),h=s(531);const v=()=>({wrapper:g.css`
      font-family: Open Sans;
      position: relative;
    `,svg:g.css`
      position: absolute;
      top: 0;
      left: 0;
    `,textBox:g.css`
      position: absolute;
      bottom: 0;
      left: 0;
      padding: 10px;
    `}),w=new c.PanelPlugin(({options:e,data:t,width:a,height:r,fieldConfig:n,id:o})=>{const l=(0,x.useTheme2)(),i=(0,x.useStyles2)(v);return 0===t.series.length?f().createElement(h.PanelDataErrorView,{fieldConfig:n,panelId:o,data:t,needsStringField:!0}):f().createElement("div",{className:(0,g.cx)(i.wrapper,g.css`
          width: ${a}px;
          height: ${r}px;
        `)},f().createElement("svg",{className:i.svg,width:a,height:r,xmlns:"http://www.w3.org/2000/svg",xmlnsXlink:"http://www.w3.org/1999/xlink",viewBox:`-${a/2} -${r/2} ${a} ${r}`},f().createElement("g",null,f().createElement("circle",{"data-testid":"simple-panel-circle",style:{fill:l.colors.primary.main},r:100}))),f().createElement("div",{className:i.textBox},e.showSeriesCount&&f().createElement("div",{"data-testid":"simple-panel-series-counter"},"Number of series: ",t.series.length),f().createElement("div",null,"Text option value: ",e.text)))}).setPanelOptions(e=>e.addTextInput({path:"text",name:"Simple text option",description:"Description of panel option",defaultValue:"Default value of text input option"}).addBooleanSwitch({path:"showSeriesCount",name:"Show series counter",defaultValue:!1}).addRadio({path:"seriesCountSize",defaultValue:"sm",name:"Series counter size",settings:{options:[{value:"sm",label:"Small"},{value:"md",label:"Medium"},{value:"lg",label:"Large"}]},showIf:e=>e.showSeriesCount}));return p})());
//# sourceMappingURL=module.js.map