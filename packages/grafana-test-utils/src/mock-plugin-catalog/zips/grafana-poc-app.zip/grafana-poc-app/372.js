"use strict";(self.webpackChunkgrafana_poc_app=self.webpackChunkgrafana_poc_app||[]).push([[372],{611(a,t,e){e.d(t,["b",0,{appConfig:{apiKey:"data-testid ac-api-key",apiUrl:"data-testid ac-api-url",submit:"data-testid ac-submit-form"},pageOne:{container:"data-testid pg-one-container",navigateToFour:"data-testid navigate-to-four"},pageTwo:{container:"data-testid pg-two-container"},pageThree:{container:"data-testid pg-three-container"},pageFour:{container:"data-testid pg-four-container",navigateBack:"data-testid navigate-back"}}])},372(a,t,e){e.r(t);var n=e(959),i=e.n(n),c=e(89),o=e(781),r=e(7),s=e(351),d=e(175),p=e(611),g=e(531);const u=function(){const a=(0,r.useStyles2)(l);return i().createElement(g.PluginPage,{layout:o.PageLayoutType.Canvas},i().createElement("div",{className:a.page,"data-testid":p.b.pageFour.container},i().createElement("div",{className:a.container},i().createElement(r.LinkButton,{"data-testid":p.b.pageFour.navigateBack,icon:"arrow-left",href:(0,d._)(s.b.One)},"Back"),i().createElement("div",{className:a.content},"This is a full-width page without a navigation bar."))))},l=a=>({page:c.css`
    padding: ${a.spacing(3)};
    background-color: ${a.colors.background.secondary};
    display: flex;
    justify-content: center;
  `,container:c.css`
    width: 900px;
    max-width: 100%;
    min-height: 500px;
  `,content:c.css`
    margin-top: ${a.spacing(6)};
  `});e.d(t,["default",0,u])},175(a,t,e){e.d(t,{_:()=>i});var n=e(351);function i(a){return`${n.G}/${a}`}}}]);
//# sourceMappingURL=372.js.map?_cache=11d357fa57c0aa485486